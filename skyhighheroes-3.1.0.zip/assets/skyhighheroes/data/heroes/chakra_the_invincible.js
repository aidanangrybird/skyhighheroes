var chakraSuit = implement("skyhighheroes:external/chakra_suit");
var uuid = "87fa6187-4fa6-4dc6-8742-19a2b67c4cc0";
function init(hero) {
  chakraSuit.initChakras(hero, "Chakra");
};