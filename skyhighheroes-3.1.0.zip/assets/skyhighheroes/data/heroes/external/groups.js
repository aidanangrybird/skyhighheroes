function initModule(system) {
  /**
   * Adds group
   * @param {JSEntity} entity - Required
   * @param {JSDataManager} manager - Required
   * @param {string} groupName - Name of group
   **/
  function addGroup(entity, manager, groupName) {
    var nbt = null;
    if (entity.getWornHelmet().nbt().hasKey("computerID")) {
      nbt = entity.getWornHelmet().nbt();
    };
    if (entity.getWornChestplate().nbt().hasKey("computerID")) {
      nbt = entity.getWornChestplate().nbt();
    };
    if (entity.getWornLeggings().nbt().hasKey("computerID")) {
      nbt = entity.getWornLeggings().nbt();
    };
    if (entity.getWornBoots().nbt().hasKey("computerID")) {
      nbt = entity.getWornBoots().nbt();
    };
    if (!nbt.hasKey("groups")) {
      var newGroupsList = manager.newTagList();
      manager.setTagList(nbt, "groups", newGroupsList);
    };
    var group = manager.newCompoundTag();
    var members = manager.newTagList();
    manager.appendString(members, entity.getName());
    manager.setString(group, "groupName", groupName);
    manager.setTagList(group, "members", members);
    var groups = nbt.getTagList("groups");
    var groupIndex = getGroupArray(entity, manager).indexOf(groupName);
    if (groupIndex > -1) {
      system.moduleMessage(this, entity, "<e>Duplicate group name <eh>" + groupName + "<e>!");
    } else {
      system.moduleMessage(this, entity, "<s>Group created with name: <sh>" + groupName + "<s>!");
      manager.appendTag(groups, group);
    };
  };
  /**
   * List groups
   * @param {JSEntity} entity - Required
   * @param {JSDataManager} manager - Required
   **/
  function listGroups(entity, manager) {
    if (!nbt.hasKey("groups")) {
      var newGroupsList = manager.newTagList();
      manager.setTagList(nbt, "groups", newGroupsList);
    };
    var groups = getGroupArrayMembers(entity, manager);
    system.moduleMessage(this, entity, "<n>You are in <nh>" + groups.length + ((groups.length == 1) ? "<n> group!" : "<n> groups!"));
    groups.forEach(entry => {
      system.moduleMessage(this, entity, "<nh>" + entry.groupName + "<n> (<nh>" + entry.memberCount + ((entry.memberCount > 1) ? "<n> members)" : "<n> member)"))
    });
  };
  /**
   * Remove group by group name
   * @param {JSEntity} entity - Required
   * @param {JSDataManager} manager - Required
   * @param {string} groupName - Name of group
   **/
  function removeGroup(entity, manager, groupName) {
    var nbt = null;
    if (entity.getWornHelmet().nbt().hasKey("computerID")) {
      nbt = entity.getWornHelmet().nbt();
    };
    if (entity.getWornChestplate().nbt().hasKey("computerID")) {
      nbt = entity.getWornChestplate().nbt();
    };
    if (entity.getWornLeggings().nbt().hasKey("computerID")) {
      nbt = entity.getWornLeggings().nbt();
    };
    if (entity.getWornBoots().nbt().hasKey("computerID")) {
      nbt = entity.getWornBoots().nbt();
    };
    if (!nbt.hasKey("groups")) {
      var newGroupsList = manager.newTagList();
      manager.setTagList(nbt, "groups", newGroupsList);
    };
    var groups = nbt.getTagList("groups");
    var groupIndex = getGroupArray(entity).indexOf(groupName);
    if (groupIndex < 0) {
      system.moduleMessage(this, entity, "<e>Unable to find group with name <eh>" + groupName + "<e> to remove!");
    } else {
      system.moduleMessage(this, entity, "<e>Removed group <eh>" + groupName + "<e>!");
      manager.removeTag(groups, groupIndex);
    };
  };
  /**
   * Adds member to group
   * @param {JSEntity} entity - Required
   * @param {JSDataManager} manager - Required
   * @param {string} groupName - Name of group to add member to
   * @param {string} username - Username to add to group
   **/
  function addGroupMember(entity, manager, groupName, username) {
    var nbt = null;
    if (entity.getWornHelmet().nbt().hasKey("computerID")) {
      nbt = entity.getWornHelmet().nbt();
    };
    if (entity.getWornChestplate().nbt().hasKey("computerID")) {
      nbt = entity.getWornChestplate().nbt();
    };
    if (entity.getWornLeggings().nbt().hasKey("computerID")) {
      nbt = entity.getWornLeggings().nbt();
    };
    if (entity.getWornBoots().nbt().hasKey("computerID")) {
      nbt = entity.getWornBoots().nbt();
    };
    var groups = nbt.getTagList("groups");
    var groupIndex = getGroupArray(entity).indexOf(groupName);
    var members = groups.getCompoundTag(groupIndex).getStringList("members");
    var memberIndex = system.getStringArray(members).indexOf(username);
    var contacts = nbt.getTagList("contacts");
    var contactIndex = system.getStringArray(contacts).indexOf(username);
    if (!nbt.hasKey("groups")) {
      system.moduleMessage(this, entity, "<e>You have not set up any groups yet!");
    } else if (groupIndex < 0) {
      system.moduleMessage(this, entity, "<e>Group <eh>" + groupName + "<e> does not exist!");
    } else if (contactIndex < 0) {
      system.moduleMessage(this, entity, "<eh>" + username + "<e> is not added as a contact!")
    } else if (memberIndex > -1) {
      system.moduleMessage(this, entity, "<e>Member <eh>" + username + "<e> is already in group <eh>" + groupName + "<e>!");
    } else {
      system.moduleMessage(this, entity, "<s>Successfully added <sh>" + username  + "<s> to group <sh>" + groupName + "<s>!");
      manager.appendString(members, username);
    };
  };
  /**
   * Adds member to group
   * @param {JSEntity} entity - Required
   * @param {JSDataManager} manager - Required
   * @param {string} groupName - Name of group to add member to
   * @param {string} username - Username to add to group
   **/
  function removeGroupMember(entity, manager, groupName, username) {
    var nbt = null;
    if (entity.getWornHelmet().nbt().hasKey("computerID")) {
      nbt = entity.getWornHelmet().nbt();
    };
    if (entity.getWornChestplate().nbt().hasKey("computerID")) {
      nbt = entity.getWornChestplate().nbt();
    };
    if (entity.getWornLeggings().nbt().hasKey("computerID")) {
      nbt = entity.getWornLeggings().nbt();
    };
    if (entity.getWornBoots().nbt().hasKey("computerID")) {
      nbt = entity.getWornBoots().nbt();
    };
    if (!nbt.hasKey("groups")) {
      var newGroupsList = manager.newTagList();
      manager.setTagList(nbt, "groups", newGroupsList);
    };
    var groups = nbt.getTagList("groups");
    var groupIndex = getGroupArray(entity).indexOf(groupName);
    var members = groups.getCompoundTag(groupIndex).getStringList("members");
    var memberIndex = system.getStringArray(members).indexOf(username);
    if (groupIndex < 0) {
      system.moduleMessage(this, entity, "<e>Group <eh>" + groupName + "<e> does not exist!");
    } else if (memberIndex < 0) {
      system.moduleMessage(this, entity, "<eh>" + username + "<e> is not in group <eh>" + groupName + "<e>!");
    } else {
      system.moduleMessage(this, entity, "<s>Successfully removed <sh>" + username  + "<s> from group <sh>" + groupName + "<s>!");
      manager.removeTag(members, memberIndex);
    };
  };
  /**
   * Lists members of group
   * @param {JSEntity} entity - Required
   * @param {integer} groupName - Name of group to add member to
   **/
  function listGroupMembers(entity, manager, groupName) {
    var nbt = null;
    if (entity.getWornHelmet().nbt().hasKey("computerID")) {
      nbt = entity.getWornHelmet().nbt();
    };
    if (entity.getWornChestplate().nbt().hasKey("computerID")) {
      nbt = entity.getWornChestplate().nbt();
    };
    if (entity.getWornLeggings().nbt().hasKey("computerID")) {
      nbt = entity.getWornLeggings().nbt();
    };
    if (entity.getWornBoots().nbt().hasKey("computerID")) {
      nbt = entity.getWornBoots().nbt();
    };
    if (!nbt.hasKey("groups")) {
      var newGroupsList = manager.newTagList();
      manager.setTagList(nbt, "groups", newGroupsList);
    };
    var groups = nbt.getTagList("groups");
    var groupIndex = getGroupArray(entity).indexOf(groupName);
    var members = system.getStringArray(groups.getCompoundTag(groupIndex).getStringList("members"));
    if (groupIndex < 0) {
      system.moduleMessage(this, entity, "<e>Group <eh>" + groupName + "<e> does not exist!");
    } else {
      system.moduleMessage(this, entity, "<s>Members in <sh>" + groupName + "<s>:")
      members.forEach(entry => {
        system.moduleMessage(this, entity, "<sh>" + entry);
      });
    };
  };
  /**
   * Turns NBT String List into an array for easier use in code
   * @param {JSEntity} entity - Entity to create group array from
   * @returns Array of group names
   **/
  function getGroupArray(entity, manager) {
    var nbt = null;
    if (entity.isWearingFullSuit()) {
      if (entity.getWornHelmet().nbt().hasKey("computerID")) {
        nbt = entity.getWornHelmet().nbt();
      };
      if (entity.getWornChestplate().nbt().hasKey("computerID")) {
        nbt = entity.getWornChestplate().nbt();
      };
      if (entity.getWornLeggings().nbt().hasKey("computerID")) {
        nbt = entity.getWornLeggings().nbt();
      };
      if (entity.getWornBoots().nbt().hasKey("computerID")) {
        nbt = entity.getWornBoots().nbt();
      };
    };
    if (!nbt.hasKey("groups")) {
      var newGroupsList = manager.newTagList();
      manager.setTagList(nbt, "groups", newGroupsList);
    };
    var groupList = nbt.getTagList("groups");
    var count = groupList.tagCount();
    var result = [];
    for (i=0;i<count;i++) {
      result.push(groupList.getCompoundTag(i).getString("groupName"));
    };
    return result;
  };
  /**
   * Turns NBT String List into an array for easier use in code
   * @param {JSEntity} entity - Entity to create group array from
   * @returns Array of group names and member counts
   **/
  function getGroupArrayMembers(entity, manager) {
    var nbt = null;
    if (entity.isWearingFullSuit()) {
      if (entity.getWornHelmet().nbt().hasKey("computerID")) {
        nbt = entity.getWornHelmet().nbt();
      };
      if (entity.getWornChestplate().nbt().hasKey("computerID")) {
        nbt = entity.getWornChestplate().nbt();
      };
      if (entity.getWornLeggings().nbt().hasKey("computerID")) {
        nbt = entity.getWornLeggings().nbt();
      };
      if (entity.getWornBoots().nbt().hasKey("computerID")) {
        nbt = entity.getWornBoots().nbt();
      };
    };
    if (!nbt.hasKey("groups")) {
      var newGroupsList = manager.newTagList();
      manager.setTagList(nbt, "groups", newGroupsList);
    };
    var groupList = nbt.getTagList("groups");
    var count = groupList.tagCount();
    var result = [];
    for (i=0;i<count;i++) {
      var group = groupList.getCompoundTag(i);
      var entry = {
        "groupName": group.getString("groupName"),
        "memberCount": group.getStringList("members").tagCount(),
      };
      result.push(entry);
    };
    return result;
  };
  return {
    name: "groups",
    moduleMessageName: "Groups",
    type: 1,
    command: "g",
    helpMessage: "<n>!g <nh>-<n> Groups",
    commandHandler: function (entity, manager, argList) {
      if (argList.length > 1 && argList.length < 4) {
        switch (argList[1]) {
          case "add":
            (argList.length == 3) ? addGroup(entity, manager, argList[2]) : system.moduleMessage(this, entity, "<n>!g add <nh><name>");
            break;
          case "rem":
            (argList.length == 3) ? removeGroup(entity, manager, argList[2]) : system.moduleMessage(this, entity, "<n>!g rem <nh><name>");
            break;
          case "list":
            listGroups(entity, manager);
            break;
          case "addMem":
            (argList.length == 3) ? addGroupMember(entity, manager, entity.getData("skyhighheroes:dyn/group_name"), argList[2]) : system.moduleMessage(this, entity, "<n>!g addMem <nh><name>");
            break;
          case "remMem":
            (argList.length == 3) ? removeGroupMember(entity, manager, entity.getData("skyhighheroes:dyn/group_name"), argList[2]) : system.moduleMessage(this, entity, "<n>!g remMem <nh><name>");
            break;
          case "listMem":
            listGroupMembers(entity, manager, entity.getData("skyhighheroes:dyn/group_name"));
            break;
          case "help":
            system.moduleMessage(this, entity, "Group commands:")
            system.moduleMessage(this, entity, "<n>!g add <nh><name><n> <nh>-<n> Creates group by name");
            system.moduleMessage(this, entity, "<n>!g rem <nh><name><n> <nh>-<n> Removes group by name");
            system.moduleMessage(this, entity, "<n>!g list <nh>-<n> Lists groups");
            system.moduleMessage(this, entity, "Below commands apply to the currently selected group!")
            system.moduleMessage(this, entity, "<n>!g addMem <nh><name><n> <nh>-<n> Adds member to currently selected group");
            system.moduleMessage(this, entity, "<n>!g remMem <nh><name><n> <nh>-<n> Removes member from currently selected group");
            system.moduleMessage(this, entity, "<n>!g listMem <nh>-<n> Lists members in currently selected group");
            system.moduleMessage(this, entity, "<n>!g help <nh>-<n> Shows this list");
            break;
          default:
            system.moduleMessage(this, entity, "<e>Unknown group command! Try <eh>!g help<e> for a list of commands!");
            break;
        };
      } else {
        system.moduleMessage(this, entity, "<e>Unknown group command! Try <eh>!g help<e> for a list of commands!");
      };
    },
  };
};
