extend("skyhighheroes:base_transer");

loadTextures({
  "transer": "skyhighheroes:pegasus_transer",
});