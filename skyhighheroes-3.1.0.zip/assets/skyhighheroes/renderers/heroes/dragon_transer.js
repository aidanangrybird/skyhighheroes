extend("skyhighheroes:base_transer");

loadTextures({
  "transer": "skyhighheroes:dragon_transer",
});