extend("skyhighheroes:base_transer");

loadTextures({
  "transer": "skyhighheroes:leo_transer",
});